from sympy import *
from typing import List
import matplotlib.pyplot as plt